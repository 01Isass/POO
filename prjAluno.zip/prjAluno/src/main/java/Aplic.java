import java.util.Scanner;
/**
 *
 * @author Isabelli Alves
 */
public class Aplic {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in); //add obj entrada da classe Scanner
        
        Aluno objAluno = new Aluno(); // criado objAluno da classe Aluno
        
        int RA, opcao; //precisa criar variavel para todos que vão ser setados no obj, ou seja, que vão ser dados pelo usuário
        double ntProva1, ntProva2, ntTrab1, ntTrab2; 
        
        System.out.println("Digite o RA do aluno: ");
        RA = entrada.nextInt();
        System.out.println("Digite a nota da primeira prova: ");
        ntProva1 = entrada.nextDouble();
        System.out.println("Digite a nota da segunda prova: ");
        ntProva2 = entrada.nextDouble();
        System.out.println("Digite a nota do primeiro trabalho: ");
        ntTrab1 = entrada.nextDouble();
        System.out.println("Digite a nota do segundo trabalho: ");
        ntTrab2 = entrada.nextDouble();
        
        objAluno.setRA(RA);
        objAluno.setNtPrv1(ntProva1);
        objAluno.setNtPrv2(ntProva2);
        objAluno.setNtTrab1(ntTrab1);
        objAluno.setNtTrab2(ntTrab2);
        
        do {
            System.out.println("\n1 - Exibir Nota das Provas e dos Trabalhos");
            System.out.println("2 - Exibir Média dos Trabalhos e das Provas");
            System.out.println("3 - Exibir Média Final");
            System.out.println("4 - Sair");
            
            opcao = entrada.nextInt();
            
            switch(opcao) {
                case 1:
                    System.out.println("\nA nota da primeira prova foi: " + objAluno.getNtPrv1() + "\nA nota da segunda prova foi: " + objAluno.getNtPrv2() + "\nA nota do primeiro trabalho foi: " + objAluno.getNtTrab1() + "\nA nota do segundo trabalho foi: " + objAluno.getNtPrv2());
                    break;
                case 2:
                    System.out.println("\nA média das provas foi: " + objAluno.calcMediaProva());
                    System.out.println("\nA média dos trabalhos foi: " + objAluno.calcMediaTrab());
                    break;
                case 3:
                    System.out.println("\nA média final foi: " + objAluno.calcMediaFinal());
                    break;
                case 4:
                    System.out.println("\nObrigad@ por usar nosso programa! Caso possa nos ajudar envie pix no seguinte número: 15 123456789");
                    break;
                default:
                    System.out.println("Opção inválida");
            }
            
        } while (opcao != 4);
        
    }
}
