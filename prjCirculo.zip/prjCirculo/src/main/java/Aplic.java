import java.util.Scanner;
/**
 *
 * @author Isabelli Alves
 */
public class Aplic {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        double raio;
        Circulo objCirculo = new Circulo(); //instanciando um objeto da classe Circulo
        
        
        System.out.println("Digite a medida do raio: ");
        raio = entrada.nextDouble(); //Usuário passou a medida do raio
        
        objCirculo.setRaio(raio); //Aqui estamos passando a medida do usuário para o objeto
        System.out.println("A medida da área do círculo é: " + objCirculo.calcArea());
        System.out.println("A medida do diâmetro do circulo é: " + objCirculo.calcDiametro());
        System.out.printf("A medida do perímetro do circulo é: %.2f", objCirculo.calcPerimetro()); //Desse jeito APENAS usando o printf consegue deixar para mostrar apenas as 2 casas dps da virgula
    }
}
