import java.util.Scanner;
/**
 *
 * @author Isabelli Alves
 */
public class Aplic {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        double raio;
        String unidadeMedida;
        
        System.out.println("Digite a unidade de medida: ");
        unidadeMedida = entrada.next();
        
        Circulo objCirculo = new Circulo(unidadeMedida); //instanciando um objeto da classe Circulo e já passa a unidade de medida
        
        System.out.println("Digite a medida do raio: ");
        raio = entrada.nextDouble(); //Usuário passou a medida do raio
        
        objCirculo.setRaio(raio); //Aqui estamos passando a medida do usuário para o objeto
        System.out.println("A medida da área do círculo é: " + objCirculo.calcArea() + " " + objCirculo.getUnidadeMedida() + "²");
        System.out.println("A medida do diâmetro do circulo é: " + objCirculo.calcDiametro() + " " + objCirculo.getUnidadeMedida());
        System.out.printf("A medida do perímetro do circulo é: " + objCirculo.calcPerimetro() + " " + objCirculo.getUnidadeMedida()); //Desse jeito APENAS usando o printf consegue deixar para mostrar apenas as 2 casas dps da virgula
    }
}
