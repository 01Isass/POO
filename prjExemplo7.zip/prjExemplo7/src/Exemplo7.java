/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 0030482423047
 */
public class Exemplo7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     
        int [] TabNum; //Declaração
        int Cont;
        
        TabNum = new int[3]; // Criação
        
        TabNum[0] = 34;
        TabNum[1] = 18;
        TabNum[2] = 27;
        
        for(Cont=0; Cont < 3; Cont++){
            System.out.print("Conteúdo de TabNum[" + Cont + "] = ");
            System.out.println(TabNum[Cont]);
        }
    }
}
