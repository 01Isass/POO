/**
 *
 * @author 0030482423047
 */
public class Aplic {
    public static void main(String[] args) {
        //definição do ponteiro para um objeto
        Retangulo objRet; //Nome da classe(Retangulo)e depois obj(nomedaclasse)
        
        //instanciação (alocação) de um objeto da classe Retangulo
        objRet = new Retangulo(); //agora foi criado o objeto
        
        //Passagem de mensagens
        objRet.setAltura(5.0);
        objRet.setBase(8.0);
        
        System.out.println("Medida da altura do retângulo: " + objRet.getAltura());
        System.out.println("Medida da base do retângulo: " + objRet.getBase());
        System.out.println("Medida da área do retângulo: " + objRet.calcArea());
        System.out.println("Medida do perímetro do retângulo: " + objRet.calcPerimetro());
    }
    
    //calculo da raiz quadrada Math.sqrt
    //potencia = Math.pow
}
