/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prjexemploretangulo_2;
/**
 *
 * @author Isabelli Alves
 */
public class Aplic {

    public static void main(String[] args) {
        //definição do ponteiro para um objeto
        calcRetangulo objCalcRet; //Nome da classe(Retangulo)e depois obj(nomedaclasse)
        
        //instanciação (alocação) de um objeto da classe Retangulo
        objCalcRet = new calcRetangulo(); //agora foi criado o objeto
        
        //Passagem de mensagens
        objCalcRet.setAltura(3.0);
        objCalcRet.setBase(4.0);
        
        System.out.println("Medida da altura do retângulo: " + objCalcRet.getAltura());
        System.out.println("Medida da base do retângulo: " + objCalcRet.getBase());
        System.out.println("Medida da área do retângulo: " + objCalcRet.calcArea());
        System.out.println("Medida do perímetro do retângulo: " + objCalcRet.calcPerimetro());
        System.out.println("Medida da diagonal do retângulo: " + objCalcRet.calcDiagonal());
    }
    
    //calculo da raiz quadrada Math.sqrt
    //potencia = Math.pow
}
