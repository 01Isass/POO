/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjexemploretangulo_2;

/**
 *
 * @author Isabelli Alves
 */
public class calcRetangulo {
    private double altura;
    private double base;
    
    public void setAltura (double a) {
        altura = a;
    }
    
    public void setBase(double b) {
        base = b;
    }
    
    public double getAltura() {
        return(altura);
    }
    
    public double getBase() {
        return(base);
    }
    
    public double calcArea () {
        return (altura*base);
    }
    
    public double calcPerimetro () {
        return (2*(altura+base));
    }
    
    public double calcDiagonal() {
        return(Math.sqrt(Math.pow(base, 2) + Math.pow(altura, 2)));
    }
//Fim classe
}
